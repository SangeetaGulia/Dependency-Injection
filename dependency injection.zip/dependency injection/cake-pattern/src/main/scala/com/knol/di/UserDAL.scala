package com.knol.di

trait UserDALComponent {

  val userDAL: UserDAL

  class UserDAL {
    // a dummy data access layer  that is not persisting anything
    def getUser(id: String): User = {
      val user = User("12334", "testUser", "test@knoldus.com")
      println("UserDAL: Getting user " + user)
      user
    }
    def create(user: User) = {
      println("UserDAL: creating user: " + user)
    }
    def delete(user: User) = {
      println("UserDAL: deleting user: " + user)
    }

  }
}
case class User(id: String, name: String, email: String)