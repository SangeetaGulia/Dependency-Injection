package com.knol.di

trait UserServiceComponent { this: UserDALComponent =>

  val userService: UserService

  class UserService {

    def getUserInfo(id: String): User = {
      val user = userDAL.getUser(id)
      println("UserService: Getting user " + user)
      user
    }

    def createUser(user: User) = {
      userDAL.create(user)
      println("UserService: creating user: " + user)
    }

    def deleteUser(user: User) = {
      userDAL.delete(user)
      println("UserService: deleting user: " + user)
    }

  }
}