package com.knol.app

import com.knol.di.UserServiceComponent
import com.knol.di.UserDALComponent

object User extends UserServiceComponent with UserDALComponent {

  val userService = new UserService
  val userDAL = new UserDAL

}

object UserApp extends App {

  import User.userService._

  println(getUserInfo(""))
}