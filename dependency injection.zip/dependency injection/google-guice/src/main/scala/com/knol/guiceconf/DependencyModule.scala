package com.knol.guiceconf

import com.google.inject.{ Inject, Module, Binder, Guice }
import com.knol.di.UserDALComponent
import com.knol.di.UserDAL
import com.google.inject.name.Names

class DependencyModule extends Module {
  
  def configure(binder: Binder) = {
    binder.bind(classOf[UserDALComponent]).to(classOf[UserDAL])

  }
  
  
}