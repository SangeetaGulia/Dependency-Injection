package com.knol.di

trait UserDALComponent {

  def getUser(id: String): User
  def create(user: User)
  def delete(user: User)

}

class UserDAL extends UserDALComponent {
  // a dummy data access layer  that is not persisting anything
  def getUser(id: String): User = {
    val user = User("12334", "testUser", "test@knoldus.com")
    println("UserDAL: Getting user " + user)
    user
  }
  def create(user: User) = {
    println("UserDAL: creating user: " + user)
  }
  def delete(user: User) = {
    println("UserDAL: deleting user: " + user)
  }

}
case class User(id: String, name: String, email: String)