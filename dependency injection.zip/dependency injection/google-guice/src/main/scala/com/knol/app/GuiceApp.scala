package com.knol.app

import com.google.inject.Guice
import com.knol.guiceconf.DependencyModule
import com.knol.di.UserService
import com.knol.di.User

object GuiceApp extends App{
  
  
   val injector = Guice.createInjector(new DependencyModule)
   
    val component = injector.getInstance(classOf[UserService])
    
    println(component.createUser(User("212","demo","app")))
    
    

}