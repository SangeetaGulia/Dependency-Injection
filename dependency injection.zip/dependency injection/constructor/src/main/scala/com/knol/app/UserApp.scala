package com.knol.app

object UserApp extends App {
  val userService = new UserService()

  userService.setUserDAL(new UserDAL())
  println(userService.getUserInfo(""))

}
