package com.knol.di

trait UserRepository {

  // a dummy data access layer  that is not persisting anything
  def getUser(id: String): User = {
    val user = User("12334", "testUser", "test@knoldus.com")
    println("UserDAL: Getting user " + user)
    user
  }
  def create(user: User) = {
    println("UserDAL: creating user: " + user)
  }
  def delete(user: User) = {
    println("UserDAL: deleting user: " + user)
  }

}

// for production
object UserRepository extends UserRepository

trait MyUserService {

  val userRepository: UserRepository

  def getUserInfo(id: String): User = {
    val user = userRepository.getUser(id)
    println("UserService: Getting user " + user)
    user
  }

  def createUser(user: User) = {
    userRepository.create(user)
    println("UserService: creating user: " + user)
  }

  def deleteUser(user: User) = {
    userRepository.delete(user)
    println("UserService: deleting user: " + user)
  }

}
//for production 
class MyUserServiceImpl(val userRepository: UserRepository) extends MyUserService
//or 
object MyUserService extends MyUserService {
  val userRepository = UserRepository
}