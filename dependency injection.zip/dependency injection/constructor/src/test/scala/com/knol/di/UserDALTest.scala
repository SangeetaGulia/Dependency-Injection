package com.knol.di

import org.scalatest.FunSuite

class UserDALTest extends FunSuite {
  
  test("UserDAL: Get User data from database"){
    
    
  }

}