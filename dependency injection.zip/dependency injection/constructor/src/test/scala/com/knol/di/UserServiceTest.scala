package com.knol.di

import org.scalatest.FunSuite

class UserServiceTest extends FunSuite{

}